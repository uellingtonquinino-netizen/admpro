import 'dotenv/config'
import { app, BrowserWindow, shell, Menu, dialog } from 'electron'
import { autoUpdater }                from 'electron-updater'
import { join }                       from 'path'
import { registerAllIpc }             from './ipc'
import { initDatabase }               from './database/connection'

// NOVO: remove a barra de menu nativa (File, Edit, View, Window, Help)
// — não é usada neste app e só ocupava espaço na tela.
Menu.setApplicationMenu(null)

let win: BrowserWindow | null = null

function createWindow() {
  win = new BrowserWindow({
    width:           1280,
    height:          800,
    minWidth:        900,
    minHeight:       600,
    // CORRIGIDO: 'hiddenInset' é uma opção específica do macOS — no
    // Windows ela deixa a janela sem barra de título e sem nenhuma
    // área definida pra arrastar (o app não tem uma barra personalizada
    // ativa pra suprir isso), o que pode ter causado a tela preta.
    // Volta pra barra de título padrão do Windows.
    backgroundColor: '#0f1117',
    webPreferences: {
      preload:          join(__dirname, '../dist-preload/index.js'),
      contextIsolation: true,
      nodeIntegration:  false,
      sandbox:          false,
    },
  })

  // Dev vs produção
  // CORRIGIDO: o preload compila para dist-preload/ (ver tsconfig.preload.json),
  // não para preload/ — e a detecção de modo dev usava uma variável de ambiente
  // que nunca era definida em nenhum script do package.json. `app.isPackaged`
  // é a forma padrão e confiável do Electron para essa checagem.
  if (!app.isPackaged) {
    win.loadURL('http://localhost:5173')
    win.webContents.openDevTools({ mode: 'detach' })
  } else {
    win.loadFile(join(__dirname, '../dist/index.html'))
  }

  // Abrir links externos no browser
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url)
    return { action: 'deny' }
  })
}

// NOVO: atualização automática — o programa confere sozinho (ao abrir
// e depois a cada 4 horas) se tem uma versão nova publicada no
// GitHub Releases, baixa em segundo plano, e avisa quando estiver
// pronta pra instalar. O colega não precisa baixar nada manualmente
// de novo — só aceita reiniciar (ou o programa instala sozinho na
// próxima vez que for fechado).
function configurarAtualizacoesAutomaticas() {
  // Só faz sentido num programa instalado de verdade — em modo de
  // desenvolvimento não existe um instalador publicado pra comparar.
  if (!app.isPackaged) return

  autoUpdater.autoInstallOnAppQuit = true

  autoUpdater.on('update-downloaded', (info) => {
    dialog.showMessageBox({
      type:    'info',
      title:   'Atualização disponível',
      message: `Uma nova versão (${info.version}) foi baixada.`,
      detail:  'Ela será instalada automaticamente na próxima vez que o programa fechar. Você também pode reiniciar agora pra já usar a versão nova.',
      buttons: ['Reiniciar agora', 'Depois'],
      defaultId: 0,
    }).then(({ response }) => {
      if (response === 0) autoUpdater.quitAndInstall()
    })
  })

  autoUpdater.on('error', (err) => {
    console.error('Erro ao verificar/baixar atualização:', err)
  })

  autoUpdater.checkForUpdatesAndNotify().catch(err => {
    console.error('Erro ao checar atualização na abertura:', err)
  })

  // Programa costuma ficar aberto o dia inteiro — confere de novo
  // periodicamente, não só na abertura.
  setInterval(() => {
    autoUpdater.checkForUpdatesAndNotify().catch(() => {})
  }, 4 * 60 * 60 * 1000)
}

app.whenReady().then(() => {
  initDatabase()
  registerAllIpc()
  createWindow()
  configurarAtualizacoesAutomaticas()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

// Segurança: bloqueia navegação externa
app.on('web-contents-created', (_e, contents) => {
  contents.on('will-navigate', (event, url) => {
    if (!url.startsWith('http://localhost')) {
      event.preventDefault()
    }
  })
})
