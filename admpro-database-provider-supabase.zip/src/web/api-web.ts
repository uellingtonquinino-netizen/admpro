// NOVO: implementação de `window.api` pra versão WEB — mesmo formato
// que o preload do Electron expõe, só que cada função fala direto com
// o Supabase (a mesma lógica que já existia dentro dos handlers do
// processo main, na branch `getDatabaseProvider() === 'supabase'` —
// só "destravada" pra rodar no navegador, que não tem acesso ao
// processo do Electron).
//
// Isso é o que permite as MESMAS páginas de src/renderer/pages (as
// telas ricas que já construímos) funcionarem na web sem precisar
// reescrever a interface — só essa camada de dados muda.
//
// AINDA NÃO IMPLEMENTADO AQUI (fica pra próxima etapa, incremental):
// AP, Notas Fiscais, Lotes, Almoxarifado, Contas a Pagar/Receber,
// Supervisor, Master, Setor Pessoal, Backup, geração de PDF/documentos
// (isso precisa de uma solução própria pra web, já que hoje usa
// Node/arquivo local — não dá só pra "destravar").
import { supabase } from './supabase'

type Perfil = 'admin' | 'gestor' | 'almoxarife' | 'supervisor' | 'central' | 'master' | 'setor_pessoal'

// ── Usuários / Autenticação ────────────────────────────────
async function getCurrentProfile() {
  const { data: auth, error: authError } = await supabase.auth.getUser()
  if (authError || !auth.user) throw new Error('Sessão não encontrada. Faça login novamente.')

  const { data: usuario, error } = await supabase
    .from('usuarios')
    .select('id, empresa_id, nome, email, perfil, ativo, carimbo_url')
    .eq('auth_user_id', auth.user.id)
    .maybeSingle()
  if (error) throw new Error(error.message)
  if (!usuario || !usuario.ativo) {
    throw new Error('Sua conta ainda não está vinculada a um usuário ativo do sistema.')
  }

  const [extras, supervisorObras] = await Promise.all([
    supabase.from('usuario_permissoes_extras').select('chave, negada').eq('usuario_id', usuario.id),
    supabase.from('supervisor_obras').select('empresa_id').eq('usuario_id', usuario.id),
  ])
  if (extras.error) throw new Error(extras.error.message)
  if (supervisorObras.error) throw new Error(supervisorObras.error.message)

  return {
    ...usuario,
    perfil: usuario.perfil as Perfil,
    permissoes_extras: (extras.data ?? []).filter(row => !row.negada).map(row => row.chave),
    permissoes_negadas: (extras.data ?? []).filter(row => !!row.negada).map(row => row.chave),
    obras_supervisor: (supervisorObras.data ?? []).map(row => row.empresa_id),
  }
}

const usuarios = {
  login: async (p: { email: string; senha: string }) => {
    const { error } = await supabase.auth.signInWithPassword({ email: p.email.trim(), password: p.senha })
    if (error) throw new Error('Usuário ou senha inválidos.')
    return getCurrentProfile()
  },

  minhasObras: async (usuarioId: number) => {
    const perfil = await getCurrentProfile()
    if (perfil.id !== usuarioId) throw new Error('Não é permitido consultar obras de outro usuário.')
    const { data: links, error: linksError } = await supabase
      .from('usuario_obras').select('empresa_id').eq('usuario_id', usuarioId)
    if (linksError) throw new Error(linksError.message)
    const ids = links?.length ? links.map(l => l.empresa_id) : [perfil.empresa_id]
    const { data: obras, error } = await supabase.from('empresas').select('id, nome').in('id', ids).order('nome')
    if (error) throw new Error(error.message)
    return obras ?? []
  },

  buscarPorId: async (id: number) => {
    const { data: usuario, error } = await supabase
      .from('usuarios')
      .select('id,empresa_id,nome,email,perfil,ativo,created_at,last_login_at,carimbo_url')
      .eq('id', id).maybeSingle()
    if (error) throw new Error(error.message)
    if (!usuario) return null
    const [extras, supervisorObras, obrasExtras] = await Promise.all([
      supabase.from('usuario_permissoes_extras').select('chave,negada').eq('usuario_id', id),
      supabase.from('supervisor_obras').select('empresa_id').eq('usuario_id', id),
      supabase.from('usuario_obras').select('empresa_id').eq('usuario_id', id),
    ])
    return {
      ...usuario,
      permissoes_extras: (extras.data ?? []).filter(x => !x.negada).map(x => x.chave),
      permissoes_negadas: (extras.data ?? []).filter(x => !!x.negada).map(x => x.chave),
      obras_supervisor: (supervisorObras.data ?? []).map(x => x.empresa_id),
      obras_extras: (obrasExtras.data ?? []).map(x => x.empresa_id),
    }
  },

  listar: async (empresaId: number) => {
    const { data: lista, error } = await supabase
      .from('usuarios')
      .select('id,empresa_id,nome,email,perfil,ativo,created_at,last_login_at,carimbo_url')
      .eq('empresa_id', empresaId).order('nome')
    if (error) throw new Error(error.message)
    return Promise.all((lista ?? []).map(async u => {
      const [extras, supervisorObras, obrasExtras] = await Promise.all([
        supabase.from('usuario_permissoes_extras').select('chave,negada').eq('usuario_id', u.id),
        supabase.from('supervisor_obras').select('empresa_id').eq('usuario_id', u.id),
        supabase.from('usuario_obras').select('empresa_id').eq('usuario_id', u.id),
      ])
      return {
        ...u,
        permissoes_extras: (extras.data ?? []).filter(x => !x.negada).map(x => x.chave),
        permissoes_negadas: (extras.data ?? []).filter(x => !!x.negada).map(x => x.chave),
        obras_supervisor: (supervisorObras.data ?? []).map(x => x.empresa_id),
        obras_extras: (obrasExtras.data ?? []).map(x => x.empresa_id),
      }
    }))
  },

  atualizar: async (p: { id: number; nome: string; perfil: string; ativo: boolean }) => {
    const { error } = await supabase.from('usuarios').update({ nome: p.nome, perfil: p.perfil, ativo: p.ativo ? 1 : 0 }).eq('id', p.id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },

  definirPermissoesExtras: async (p: { usuario_id: number; extras: string[]; negadas: string[] }) => {
    const { error: apagarErro } = await supabase.from('usuario_permissoes_extras').delete().eq('usuario_id', p.usuario_id)
    if (apagarErro) throw new Error(apagarErro.message)
    const linhas = [...p.extras.map(chave => ({ usuario_id: p.usuario_id, chave, negada: 0 })), ...p.negadas.map(chave => ({ usuario_id: p.usuario_id, chave, negada: 1 }))]
    if (linhas.length) {
      const { error } = await supabase.from('usuario_permissoes_extras').insert(linhas)
      if (error) throw new Error(error.message)
    }
    return { ok: true }
  },

  definirObras: async (p: { usuario_id: number; empresa_ids: number[] }) => {
    const { error: apagarErro } = await supabase.from('usuario_obras').delete().eq('usuario_id', p.usuario_id)
    if (apagarErro) throw new Error(apagarErro.message)
    if (p.empresa_ids.length) {
      const { error } = await supabase.from('usuario_obras').insert(p.empresa_ids.map(empresa_id => ({ usuario_id: p.usuario_id, empresa_id })))
      if (error) throw new Error(error.message)
    }
    return { ok: true }
  },

  definirObrasSupervisor: async (p: { usuario_id: number; empresa_ids: number[] }) => {
    const { error: apagarErro } = await supabase.from('supervisor_obras').delete().eq('usuario_id', p.usuario_id)
    if (apagarErro) throw new Error(apagarErro.message)
    if (p.empresa_ids.length) {
      const { error } = await supabase.from('supervisor_obras').insert(p.empresa_ids.map(empresa_id => ({ usuario_id: p.usuario_id, empresa_id })))
      if (error) throw new Error(error.message)
    }
    return { ok: true }
  },

  alterarSenha: async (p: { senha_nova: string }) => {
    if (p.senha_nova.length < 6) throw new Error('A nova senha precisa ter pelo menos 6 caracteres.')
    const { error } = await supabase.auth.updateUser({ password: p.senha_nova })
    if (error) throw new Error(error.message)
    return { ok: true }
  },

  verificarSenha: async (p: { id: number; senha: string }) => {
    const perfil = await getCurrentProfile()
    if (perfil.id !== p.id) return { ok: false }
    const { error } = await supabase.auth.signInWithPassword({ email: perfil.email, password: p.senha })
    return { ok: !error }
  },

  alterarEmail: async (p: { id: number; senha_atual: string; novo_email: string }) => {
    const perfil = await getCurrentProfile()
    if (perfil.id !== p.id) throw new Error('Não é permitido alterar o e-mail de outro usuário.')
    const { error: loginError } = await supabase.auth.signInWithPassword({ email: perfil.email, password: p.senha_atual })
    if (loginError) throw new Error('Senha atual incorreta.')
    const { error } = await supabase.auth.updateUser({ email: p.novo_email.trim() })
    if (error) throw new Error(error.message)
    return { ok: true }
  },

  atualizarCarimbo: async (p: { carimbo_url: string | null }) => {
    const { error } = await supabase.rpc('atualizar_meu_carimbo', { p_carimbo_url: p.carimbo_url })
    if (error) throw new Error(error.message)
    return { ok: true }
  },

  criar: async (p: { empresa_id: number; nome: string; email: string; senha: string; perfil: string }) => {
    const { data: sessao, error: sessaoErro } = await supabase.auth.getSession()
    if (sessaoErro || !sessao.session) throw new Error('Sessão não encontrada. Faça login novamente.')
    const { data, error } = await supabase.functions.invoke('usuarios-admin', {
      body: { acao: 'criar', ...p },
      headers: { Authorization: `Bearer ${sessao.session.access_token}` },
    })
    if (error) throw new Error(error.message)
    if (data?.error) throw new Error(data.error)
    return { id: data.id }
  },

  remover: async (p: { id: number } | number) => {
    const id = typeof p === 'number' ? p : p.id
    const { data: sessao, error: sessaoErro } = await supabase.auth.getSession()
    if (sessaoErro || !sessao.session) throw new Error('Sessão não encontrada. Faça login novamente.')
    const { error } = await supabase.functions.invoke('usuarios-admin', {
      body: { acao: 'remover', id },
      headers: { Authorization: `Bearer ${sessao.session.access_token}` },
    })
    if (error) throw new Error(error.message)
    return { ok: true }
  },
}

const auth = {
  logout: async () => {
    const { error } = await supabase.auth.signOut()
    if (error) throw new Error(error.message)
    return { ok: true }
  },
  // Recuperação de senha por código ainda não portada pra web — o
  // Supabase Auth já tem o próprio fluxo de "esqueci minha senha" por
  // e-mail, que é o caminho mais natural aqui (fica pra próxima etapa).
}

// ── Empresas ────────────────────────────────────────────────
const empresas = {
  listar: async () => {
    const { data, error } = await supabase.from('empresas').select('*').eq('ativo', 1).order('nome')
    if (error) throw new Error(error.message)
    return data ?? []
  },
  buscarPorId: async (id: number) => {
    const { data, error } = await supabase.from('empresas').select('*').eq('id', id).maybeSingle()
    if (error) throw new Error(error.message)
    return data ?? null
  },
  criar: async (payload: Record<string, unknown>) => {
    const { data, error } = await supabase.from('empresas').insert({ ...payload, ativo: 1 }).select('id').single()
    if (error) throw new Error(error.message)
    return { id: data.id }
  },
  atualizar: async (payload: { id: number } & Record<string, unknown>) => {
    const { id, ...dados } = payload
    const { error } = await supabase.from('empresas').update(dados).eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
  excluir: async (id: number) => {
    const { error } = await supabase.from('empresas').delete().eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
}

// ── Dashboard (Início) ───────────────────────────────────────
const dashboard = {
  resumo: async (p: { empresa_id: number; mes?: number; ano?: number }) => {
    const { data, error } = await supabase.from('lancamentos').select('tipo,status,valor,data,data_venc').eq('empresa_id', p.empresa_id)
    if (error) throw new Error(error.message)
    const noPeriodo = (valor: string | null) => (!p.mes && !p.ano) || (!!valor && (!p.mes || Number(valor.slice(5, 7)) === p.mes) && (!p.ano || Number(valor.slice(0, 4)) === p.ano))
    let receitas = 0, despesas = 0, pendentes = 0
    for (const l of data ?? []) {
      const valor = Number(l.valor)
      if (l.tipo === 'receita' && l.status === 'pago' && noPeriodo(l.data_venc)) receitas += valor
      if (l.tipo === 'despesa' && l.status !== 'cancelado' && noPeriodo(l.data)) despesas += valor
      if (l.status === 'pendente' && noPeriodo(l.data_venc)) pendentes += valor
    }
    return { receitas, despesas, pendentes, saldo: receitas - despesas }
  },

  graficomensal: async (p: { empresa_id: number }) => {
    const { data, error } = await supabase.from('lancamentos').select('tipo,status,valor,data,data_venc').eq('empresa_id', p.empresa_id)
    if (error) throw new Error(error.message)
    const inicio = new Date(); inicio.setMonth(inicio.getMonth() - 6)
    const limite = inicio.toISOString().slice(0, 10)
    const grupos = new Map<string, { receitas: number; despesas: number }>()
    for (const l of data ?? []) {
      const dataRef = l.tipo === 'receita' ? l.data_venc : l.data
      if (!dataRef || dataRef < limite) continue
      if (l.tipo === 'receita' && l.status !== 'pago') continue
      if (l.tipo === 'despesa' && l.status === 'cancelado') continue
      const mes = dataRef.slice(0, 7)
      const g = grupos.get(mes) ?? { receitas: 0, despesas: 0 }
      if (l.tipo === 'receita') g.receitas += Number(l.valor); else g.despesas += Number(l.valor)
      grupos.set(mes, g)
    }
    return [...grupos].sort(([a], [b]) => a.localeCompare(b)).map(([mes, g]) => ({ mes, ...g }))
  },

  ultimoslanc: async (p: { empresa_id: number; limite?: number }) => {
    const [{ data: lancamentos, error: lancamentosError }, { data: categorias, error: categoriasError }, { data: contas, error: contasError }] = await Promise.all([
      supabase.from('lancamentos').select('*').eq('empresa_id', p.empresa_id).order('created_at', { ascending: false }).limit(p.limite ?? 5),
      supabase.from('categorias').select('id,nome').eq('empresa_id', p.empresa_id),
      supabase.from('contas').select('id,nome').eq('empresa_id', p.empresa_id),
    ])
    if (lancamentosError) throw new Error(lancamentosError.message)
    if (categoriasError) throw new Error(categoriasError.message)
    if (contasError) throw new Error(contasError.message)
    const categoriasPorId = new Map((categorias ?? []).map(c => [c.id, c.nome]))
    const contasPorId = new Map((contas ?? []).map(c => [c.id, c.nome]))
    const hoje = new Date().toISOString().slice(0, 10)
    return (lancamentos ?? []).map(l => ({
      ...l, categoria: categoriasPorId.get(l.categoria_id) ?? null, conta: contasPorId.get(l.conta_id) ?? null,
      situacao: l.status === 'pago' ? 'pago' : l.status === 'cancelado' ? 'cancelado' : (l.status === 'pendente' && l.data_venc < hoje) ? 'vencido' : 'a_vencer',
    }))
  },

  topCategorias: async (p: { empresa_id: number }) => {
    const [{ data: lancamentos, error: lancamentosError }, { data: categorias, error: categoriasError }] = await Promise.all([
      supabase.from('lancamentos').select('categoria_id,valor').eq('empresa_id', p.empresa_id).eq('tipo', 'despesa').eq('status', 'pago'),
      supabase.from('categorias').select('id,nome,cor').eq('empresa_id', p.empresa_id),
    ])
    if (lancamentosError) throw new Error(lancamentosError.message)
    if (categoriasError) throw new Error(categoriasError.message)
    const porId = new Map((categorias ?? []).map(c => [c.id, c]))
    const grupos = new Map<number, { nome: string; cor: string; total: number }>()
    for (const l of lancamentos ?? []) {
      if (l.categoria_id === null) continue
      const c = porId.get(l.categoria_id)
      if (!c) continue
      const g = grupos.get(l.categoria_id) ?? { nome: c.nome, cor: c.cor, total: 0 }
      g.total += Number(l.valor)
      grupos.set(l.categoria_id, g)
    }
    return [...grupos.values()].sort((a, b) => b.total - a.total).slice(0, 5)
  },
}

// ── Colaboradores (RH) ───────────────────────────────────────
function normalizarColaborador(p: Record<string, unknown>) {
  return { ...p, pcd: p.pcd ? 1 : 0, alojado: p.alojado ? 1 : 0, tem_baixada: p.tem_baixada ? 1 : 0 }
}

const colaboradores = {
  listar: async (p: { empresa_id: number; busca?: string; funcao?: string; setor?: string; equipe?: string; status?: string; page?: number; perPage?: number }) => {
    const page = p.page ?? 1, perPage = p.perPage ?? 50
    let query = supabase.from('colaboradores').select('*', { count: 'exact' }).eq('empresa_id', p.empresa_id).order('nome').range((page - 1) * perPage, page * perPage - 1)
    if (p.funcao) query = query.eq('funcao', p.funcao)
    if (p.setor) query = query.eq('setor', p.setor)
    if (p.equipe) query = query.eq('equipe', p.equipe)
    if (p.status) query = query.eq('status', p.status)
    if (p.busca) query = query.ilike('nome', `%${p.busca.replace(/[%_]/g, '\\$&')}%`)
    const { data, error, count } = await query
    if (error) throw new Error(error.message)
    return { items: data ?? [], total: count ?? 0 }
  },

  listarResumo: async (empresa_id: number) => {
    const { data, error } = await supabase.from('colaboradores').select('id,nome,cpf,funcao').eq('empresa_id', empresa_id).neq('status', 'desligado').order('nome')
    if (error) throw new Error(error.message)
    return data ?? []
  },

  buscarPorId: async (id: number) => {
    const { data, error } = await supabase.from('colaboradores').select('*').eq('id', id).maybeSingle()
    if (error) throw new Error(error.message)
    return data ?? null
  },

  criar: async (p: Record<string, unknown>) => {
    const { data, error } = await supabase.from('colaboradores').insert(normalizarColaborador(p)).select('id').single()
    if (error) throw new Error(error.message)
    return { id: data.id }
  },

  atualizar: async (p: { id: number } & Record<string, unknown>) => {
    const { id, ...dados } = p
    const { error } = await supabase.from('colaboradores').update(normalizarColaborador(dados)).eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },

  excluir: async (id: number) => {
    const { error } = await supabase.from('colaboradores').delete().eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },

  // AINDA NÃO IMPLEMENTADOS NA WEB: opcoesFiltro, historicoDocumentos,
  // registrarDocumento, listarAnexos, adicionarAnexo, removerAnexo —
  // nenhum desses tinha uma versão Supabase pronta no Electron ainda.
  opcoesFiltro: async () => ({ funcoes: [], setores: [], equipes: [] }),

  resumoRH: async (empresa_id: number) => {
    const { data, error } = await supabase.from('colaboradores').select('nome, funcao, nascimento, salario_base, status').eq('empresa_id', empresa_id)
    if (error) throw new Error(error.message)
    const rows = data ?? []
    const ativos = rows.filter(row => row.status === 'ativo')
    const porFuncao = new Map<string, { quantidade: number; custo_salarial: number }>()
    const porStatus = new Map<string, number>()
    for (const row of rows) {
      porStatus.set(row.status ?? 'sem_status', (porStatus.get(row.status ?? 'sem_status') ?? 0) + 1)
      if (row.status === 'ativo' && row.funcao) {
        const atual = porFuncao.get(row.funcao) ?? { quantidade: 0, custo_salarial: 0 }
        atual.quantidade += 1; atual.custo_salarial += Number(row.salario_base ?? 0)
        porFuncao.set(row.funcao, atual)
      }
    }
    const hoje = new Date()
    const idades = ativos.filter(row => row.nascimento).map(row => (hoje.getTime() - new Date(`${row.nascimento}T00:00:00`).getTime()) / 31557600000)
    const mesAtual = String(hoje.getMonth() + 1).padStart(2, '0')
    return {
      totalAtivos: ativos.length,
      custoFolha: ativos.reduce((total, row) => total + Number(row.salario_base ?? 0), 0),
      mediaIdade: idades.length ? Math.round(idades.reduce((a, b) => a + b, 0) / idades.length) : null,
      porFuncao: [...porFuncao].map(([funcao, dados]) => ({ funcao, ...dados })).sort((a, b) => b.quantidade - a.quantidade),
      porStatus: [...porStatus].map(([status, quantidade]) => ({ status, quantidade })),
      aniversariantes: ativos.filter(row => row.nascimento?.slice(5, 7) === mesAtual).sort((a, b) => (a.nascimento ?? '').slice(8, 10).localeCompare((b.nascimento ?? '').slice(8, 10))).map(row => ({ nome: row.nome, funcao: row.funcao, nascimento: row.nascimento })),
    }
  },
}

// ── Contas e Categorias (usadas por vários módulos) ───────────
const contas = {
  listar: async (p: { empresa_id: number }) => {
    const { data, error } = await supabase.from('contas').select('*').eq('empresa_id', p.empresa_id).eq('ativo', 1).order('nome')
    if (error) throw new Error(error.message)
    return data ?? []
  },
  buscarPorId: async (id: number) => {
    const { data, error } = await supabase.from('contas').select('*').eq('id', id).maybeSingle()
    if (error) throw new Error(error.message)
    return data ?? null
  },
  criar: async (p: Record<string, unknown>) => {
    const { data, error } = await supabase.from('contas').insert({ ...p, ativo: 1 }).select('id').single()
    if (error) throw new Error(error.message)
    return { id: data.id }
  },
  atualizar: async (p: { id: number } & Record<string, unknown>) => {
    const { id, ...dados } = p
    const { error } = await supabase.from('contas').update(dados).eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
  excluir: async (id: number) => {
    const { error } = await supabase.from('contas').update({ ativo: 0 }).eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
  saldoTotal: async (id: number) => {
    const { data, error } = await supabase.from('contas').select('saldo').eq('id', id).maybeSingle()
    if (error) throw new Error(error.message)
    return data?.saldo ?? 0
  },
}

const categorias = {
  listar: async (p: { empresa_id: number }) => {
    const { data, error } = await supabase.from('categorias').select('*').eq('empresa_id', p.empresa_id).eq('ativo', 1).order('nome')
    if (error) throw new Error(error.message)
    return data ?? []
  },
  criar: async (p: Record<string, unknown>) => {
    const { data, error } = await supabase.from('categorias').insert({ ...p, ativo: 1 }).select('id').single()
    if (error) throw new Error(error.message)
    return { id: data.id }
  },
  atualizar: async (p: { id: number } & Record<string, unknown>) => {
    const { id, ...dados } = p
    const { error } = await supabase.from('categorias').update(dados).eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
  excluir: async (id: number) => {
    const { error } = await supabase.from('categorias').update({ ativo: 0 }).eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
  sugestoes: async () => [],
}

// ── Lançamentos ───────────────────────────────────────────────
const lancamentos = {
  listar: async (p: { empresa_id: number; busca?: string; tipo?: string; status?: string; page?: number; perPage?: number }) => {
    const page = p.page ?? 1, perPage = p.perPage ?? 50
    let query = supabase.from('lancamentos').select('*', { count: 'exact' }).eq('empresa_id', p.empresa_id).order('data_venc', { ascending: false }).range((page - 1) * perPage, page * perPage - 1)
    if (p.tipo) query = query.eq('tipo', p.tipo)
    if (p.status) query = query.eq('status', p.status)
    if (p.busca) query = query.ilike('descricao', `%${p.busca.replace(/[%_]/g, '\\$&')}%`)
    const { data, error, count } = await query
    if (error) throw new Error(error.message)
    return { items: data ?? [], total: count ?? 0 }
  },
  buscarPorId: async (id: number) => {
    const { data, error } = await supabase.from('lancamentos').select('*').eq('id', id).maybeSingle()
    if (error) throw new Error(error.message)
    return data ?? null
  },
  criar: async (p: Record<string, unknown>) => {
    const { data, error } = await supabase.from('lancamentos').insert(p).select('id').single()
    if (error) throw new Error(error.message)
    return { id: data.id }
  },
  atualizar: async (p: { id: number } & Record<string, unknown>) => {
    const { id, ...dados } = p
    const { error } = await supabase.from('lancamentos').update(dados).eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
  excluir: async (id: number) => {
    const { error } = await supabase.from('lancamentos').delete().eq('id', id)
    if (error) throw new Error(error.message)
    return { ok: true }
  },
}

export const apiWeb = {
  usuarios, auth, empresas, dashboard, colaboradores, contas, categorias, lancamentos,
  // NOVO: módulos que ainda faltam — ver anotação no topo do arquivo.
}
